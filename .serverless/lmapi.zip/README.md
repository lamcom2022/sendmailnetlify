# netlify-

# Reference

https://github.com/owenconti/netlify-express

https://www.youtube.com/watch?v=hQAu0YEIF0g

# Hostinger CC Mail

# lamhouse.in
username: ravinther@lamhouse.in
password: l@mhousE12#

username: pradeep@lamhouse.in
password: l@mhousE12#

username: suresh@lamhouse.in
password: am@zecH12#
